================================================================================
|     __________             .___.______  _______  _______ ____                |
|     \______   \_____     __| _/|__\   \/  /\   \/  /_   /_   |               |
|      |       _/\__  \   / __ | |  |\     /  \     / |   ||   |               |
|      |    |   \ / __ \_/ /_/ | |  |/     \  /     \ |   ||   |               |
|      |____|_  /(____  /\____ | |__/___/\  \/___/\  \|___||___|               |
|             \/      \/      \/          \_/      \_/           [ 2019 ]      |
+------------------------------------------------------------------------------+

==[ RELEASE INFO ]==============================================================
|                                                                              |
| > Name......: High-Logic Products Keygen                                     |
| > Date......: 2019-09-12                                                     |
| > Version...: 1.0                                                            |
| > File......: Keygen.exe                                                     |
| > MD5.......: 12c4cebf99c841d2972f09681b5f16d5                               |
| > SHA1......: be34cfce028afb8ff7e3eee231bacfbe2bbc016b                       |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET INFO ]===============================================================
|                                                                              |
| > Category..: Font Utils                                                     |
| > Protection: RSA/Custom                                                     |
| > OS........: WinALL                                                         |
| > Homepage..: https://www.high-logic.com                                     |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET DESCRIPTION ]========================================================
|                                                                              |
| FontCreator                                                                  |
| ===========                                                                  |
| When you create or open a font, FontCreator displays an overview of all      |
| available characters. You can simply add missing characters, or select an    |
| existing character, and modify its appearance. You can import (scanned)      |
| images of your signature or company logo, or make a font from your own       |
| handwriting. With FontCreator you can also fix character code-points, font   |
| names, glyph names, and kerning pairs. At any time you can preview your      |
| typefaces before installation. OpenType features are preserved on opening a  |
| font. This professional font editor supports both quadratic- and cubic-based |
| contours and has several smart features to ensure smooth connections where   |
| you need them. The validation features help you locate and fix possible      |
| outline issues.                                                              |
|                                                                              |
| FontCreator is a true native font editor, so there is no need to buy or      |
| install third-party tools or extensions.                                     |
|                                                                              |
| MainType                                                                     |
| ========                                                                     |
| MainType is designed for graphic artists, typographers, and other power      |
| users who demand high-end functionality such as network support, advanced    |
| categorizing, and complex searching capabilities. MainType provides          |
| immediate system-wide font synchronization, with no need to refresh font     |
| lists or reboot the computer after installing fonts. Unlike most other font  |
| managers, MainType runs without administrator credentials. This eliminates   |
| the frustrating elevation prompt when managing your fonts.                   |
|                                                                              |
| Scanahand                                                                    |
| =========                                                                    |
| How does it work? Simply print a template, draw all of the characters using  |
| a black marker or felt-tip pen, and scan your drawing. Scanahand will build  |
| your font, and install it on Windows, ready for you to use. You don't need   |
| to use additional graphics software, but Power Users and Hobbyists alike can |
| use Scanahand along with their favorite graphic drawing software to create   |
| or modify each character of their font. So even without a printer and        |
| scanner you'll be able to create custom fonts.                               |
|                                                                              |
+------------------------------------------------------------------------------+

==[ HOW TO USE ]================================================================
|                                                                              |
| 1. Disconnect from Internet before activate.                                 |
| 2. Select the target product and complete the required fields.               |
| 3. Click "Generate" and then use the generated reg code to activate the      |
| program OR click "Activate" to save the license info directly to the         |
| registry.                                                                    |
| 4. Use "Patch Hosts" or block with firewall any outbound connection to       |
| www.high-logic.com                                                           |
|                                                                              |
+------------------------------------------------------------------------------+

==[ FOR EVALUATION PURPOSES ONLY ]==============================================
|                                                                              |
| If you can afford it, please BUY IT. Support the developer to make a better  |
| product.                                                                     |
|                                                                              |
+------------------------------------------------------------------------------+

==[ RELEASES & SOURCE CODES ]===================================================
|                                                                              |
| https://radixx11rce2.blogspot.com                                            |
|                                                                              |
+------------------------------------------------------------------------------+
